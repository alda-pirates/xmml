#ifndef SAMPLE_H
#define SAMPLE_H

namespace trackerml {
    class Sample {
    };
}


#endif
